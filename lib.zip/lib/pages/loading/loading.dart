/*
 * @Date: 2025-04-16 09:39:57
 * @LastEditTime: 2025-04-16 10:02:05
 */
import 'package:flutter/material.dart';

class Loading extends StatelessWidget {
const Loading({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context){
    Future.delayed(Duration(seconds: 3), () {
      Navigator.pushReplacementNamed(context, '/home');
    });
    return Scaffold(
      body: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}
