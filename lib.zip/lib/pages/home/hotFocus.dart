/*
 * @Date: 2025-04-16 10:37:39
 * @LastEditTime: 2025-04-16 10:45:19
 */
import 'package:flutter/material.dart';

class HotFocus extends StatelessWidget {
const HotFocus({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context){
    return Container(
      child: Center(
        child: Text('HotFocus Page'),
      ),
    );
  }
}