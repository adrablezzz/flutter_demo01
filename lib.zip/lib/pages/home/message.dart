/*
 * @Date: 2025-04-16 10:37:39
 * @LastEditTime: 2025-04-16 10:41:04
 */
import 'package:flutter/material.dart';

class Message extends StatelessWidget {
const Message({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context){
    return Container(
      child: Center(
        child: Text('Message Page'),
      ),
    );
  }
}