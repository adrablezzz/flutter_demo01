import 'package:flutter/material.dart';
import 'home.dart';
import 'hotFocus.dart';
import 'message.dart';
import 'profile.dart';

class HomeIndex extends StatefulWidget {
  const HomeIndex({Key? key}) : super(key: key);

  @override
  _HomeIndexState createState() => _HomeIndexState();
}

class _HomeIndexState extends State<HomeIndex> {
  int _currentIndex = 0;

  // 页面列表
  final List<Widget> _pages = [
    Home(),
    HotFocus(),
    Message(),
    Profile(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            // 设置线性渐变背景
            begin: Alignment.topLeft, // 左上角
            end: Alignment.bottomRight, // 右下角
            colors: [
              Color.fromRGBO(253, 232, 253, 1), // 粉红色
              Colors.white, // 白色
            ],
          ),
        ),
        child: _pages[_currentIndex],
      ),
      bottomNavigationBar: 
      BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        selectedItemColor: Colors.blue, // 选中项的文字和图标颜色
        unselectedItemColor: Colors.grey, // 未选中项的文字和图标颜色
        selectedFontSize: 14, // 选中项文字大小
        unselectedFontSize: 12, // 未选中项文字大小
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: '首页'),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: '焦点'),
          BottomNavigationBarItem(icon: Icon(Icons.message), label: '消息'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: '我的'),
        ],
      ),
    );
  }
}
