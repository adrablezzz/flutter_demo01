/*
 * @Date: 2025-04-16 09:47:41
 * @LastEditTime: 2025-04-16 19:38:41
 */
import 'package:flutter/material.dart';
import 'package:getwidget/getwidget.dart';
import '../../components/common/mediaView/ImagePreviewPage.dart';

class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          Expanded(
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: 3,
              itemBuilder: (context, index) {
                return Container(
                  margin: EdgeInsets.symmetric(horizontal: 0, vertical: 5),
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.3),
                        spreadRadius: 3,
                        blurRadius: 3,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // 头部
                      Flex(
                        direction: Axis.horizontal,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              GFAvatar(
                                backgroundImage: NetworkImage(
                                  'http://oss.linkon.me/changjia/20250224/f166d1cb-05af-4d59-ab1e-f9699146f75d.jpg',
                                ),
                                size: GFSize.SMALL,
                                shape: GFAvatarShape.circle,
                              ),
                              SizedBox(width: 10.0),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('用户名'),
                                  Text(
                                    '2025-01-19 09:09:09 发布',
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: Colors.grey,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Container(
                            child: Row(
                              children: [
                                GFButton(
                                  onPressed: () {},
                                  size: GFSize.SMALL,
                                  type: GFButtonType.outline,
                                  shape: GFButtonShape.pills,
                                  color: Colors.black54,
                                  text: "取消关注",
                                ),
                                SizedBox(width: 10.0),
                                Icon(Icons.home_filled, color: Colors.grey),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 10.0),
                      // 内容区域
                      Container(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('内容', style: TextStyle(fontSize: 12)),
                            SizedBox(height: 5.0),
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder:
                                        (_) => ImagePreviewPage(
                                          imageUrl:
                                              'http://oss.linkon.me/changjia/20250224/f166d1cb-05af-4d59-ab1e-f9699146f75d.jpg',
                                        ),
                                  ),
                                );
                              },
                              child: Image.network(
                                'http://oss.linkon.me/changjia/20250224/f166d1cb-05af-4d59-ab1e-f9699146f75d.jpg',
                                width: 200,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ],
                        ),
                      ),
                      // 底部按钮栏
                      SizedBox(height: 10.0),
                      Flex(
                        direction: Axis.horizontal,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.favorite_border,
                                color: Colors.grey,
                                size: 20,
                              ),
                              Text(
                                '997',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey,
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              Icon(
                                Icons.favorite_border,
                                color: Colors.grey,
                                size: 20,
                              ),
                              Text(
                                '999',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey,
                                ),
                              ),
                            ],
                          ),
                          Icon(
                            Icons.favorite_border,
                            color: Colors.grey,
                            size: 20,
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
