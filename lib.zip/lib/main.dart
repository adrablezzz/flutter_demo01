/*
 * @Date: 2025-04-15 14:26:02
 * @LastEditTime: 2025-04-30 14:36:36
 */
import 'package:flutter/material.dart';
import 'pages/loading/loading.dart';
import 'pages/home/index.dart';
import 'pages/settingPage/setting_page.dart';
import 'pages/postCardView/post_card_view.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Color.fromARGB(1, 139, 172, 212)),
      ),
      home: const PostCardView(),
      routes: {
        '/loading': (context) => const Loading(),
        '/homeIndex': (context) => const HomeIndex(),
        '/settingPage': (context) => const SettingPage(),
      },
    );
  }
}


